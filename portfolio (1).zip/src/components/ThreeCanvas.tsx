import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

export default function ThreeCanvas() {
  const mountRef = useRef<HTMLDivElement>(null);
  const [webglSupported, setWebglSupported] = useState(true);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Check prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Detect WebGL capability & software renderer
    let glContext: WebGL2RenderingContext | WebGLRenderingContext | null = null;
    try {
      const probeCanvas = document.createElement('canvas');
      glContext = probeCanvas.getContext('webgl2') || probeCanvas.getContext('webgl');
      if (!glContext) {
        setWebglSupported(false);
        return;
      }
    } catch {
      setWebglSupported(false);
      return;
    }

    const isSoftwareGl = (() => {
      if (!glContext) return true;
      try {
        const ext = glContext.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : glContext.RENDERER;
        const gpu = String(glContext.getParameter(param));
        glContext.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return false;
      }
    })();

    // Setup Three.js scene - Deep charcoal fog matching #14171d
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x14171d, 0.038);

    const camera = new THREE.PerspectiveCamera(
      45,
      window.innerWidth / window.innerHeight,
      0.1,
      100
    );
    camera.position.set(0, 0, 16);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        alpha: true,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglSupported(false);
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 1.75));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.display = 'block';

    container.appendChild(renderer.domElement);

    // Group for objects responsive to mouse/scroll parallax
    const worldGroup = new THREE.Group();
    scene.add(worldGroup);

    // 1. Classical Architectural Studio Lighting (Warm Champagne & Cool Mist)
    const ambientLight = new THREE.AmbientLight(0x1a1e27, 1.4);
    scene.add(ambientLight);

    const hemisphereLight = new THREE.HemisphereLight(0xd5c3aa, 0x14171d, 1.6);
    scene.add(hemisphereLight);

    // Key warm light (antique champagne gold)
    const warmKeyLight = new THREE.DirectionalLight(0xf2e6d3, 2.6);
    warmKeyLight.position.set(6, 7, 7);
    scene.add(warmKeyLight);

    // Rim light (soft marble alabaster reflection)
    const alabasterRimLight = new THREE.DirectionalLight(0xb5c3d5, 1.8);
    alabasterRimLight.position.set(-7, -4, -4);
    scene.add(alabasterRimLight);

    // Subtle warm candle/sand accent point light
    const sandAccentPoint = new THREE.PointLight(0xd5c3aa, 2.2, 22);
    sandAccentPoint.position.set(2.5, -2, 5);
    scene.add(sandAccentPoint);

    // 2. Central Classical Sculptural Cluster (Marble Torus & Architectural Cage)
    const centralCluster = new THREE.Group();
    centralCluster.position.set(3.5, 0.5, 0);
    worldGroup.add(centralCluster);

    // Carrara Alabaster Marble Material
    const marbleMat = new THREE.MeshPhysicalMaterial({
      color: 0xede8e1,
      roughness: 0.28,
      metalness: 0.12,
      clearcoat: 0.35,
      clearcoatRoughness: 0.25,
      reflectivity: 0.6,
    });

    // Antique Gold / Champagne Brushed Trim Material
    const antiqueGoldMat = new THREE.MeshPhysicalMaterial({
      color: 0xd5c3aa,
      roughness: 0.22,
      metalness: 0.75,
      clearcoat: 0.5,
    });

    // Outer Thin Wireframe Polyhedron (Geometric pedestal cage)
    const cageGeom = new THREE.IcosahedronGeometry(2.8, 0);
    const cageMat = new THREE.MeshStandardMaterial({
      color: 0xc8b59e,
      wireframe: true,
      transparent: true,
      opacity: 0.35,
    });
    const outerCage = new THREE.Mesh(cageGeom, cageMat);
    centralCluster.add(outerCage);

    // Inner Sculptural Knot in Carrara Marble
    const knotGeom = new THREE.TorusKnotGeometry(1.6, 0.42, 120, 24, 2, 3);
    const torusKnot = new THREE.Mesh(knotGeom, marbleMat);
    centralCluster.add(torusKnot);

    // Architectural Core Ring in Antique Gold
    const ringGeom = new THREE.TorusGeometry(2.2, 0.04, 16, 64);
    const ringMesh = new THREE.Mesh(ringGeom, antiqueGoldMat);
    ringMesh.rotation.x = Math.PI / 3;
    centralCluster.add(ringMesh);

    // Floating Classical Satellites (Marble Spheres, Octahedrons, Columns)
    const floatingObjects: {
      mesh: THREE.Mesh;
      baseY: number;
      speedY: number;
      rotSpeedX: number;
      rotSpeedY: number;
      phase: number;
    }[] = [];

    const satelliteConfigs = [
      { geom: new THREE.SphereGeometry(0.55, 32, 32), mat: marbleMat, pos: [6.2, 2.8, -2] },
      { geom: new THREE.OctahedronGeometry(0.7, 0), mat: antiqueGoldMat, pos: [-4.6, 2.2, -3] },
      { geom: new THREE.IcosahedronGeometry(0.65, 0), mat: marbleMat, pos: [-3.8, -3.2, -1] },
      { geom: new THREE.SphereGeometry(0.4, 24, 24), mat: antiqueGoldMat, pos: [5.2, -2.6, 1] },
      { geom: new THREE.TorusGeometry(0.75, 0.05, 16, 50), mat: antiqueGoldMat, pos: [1.5, 3.8, -2] },
      { geom: new THREE.OctahedronGeometry(0.48, 0), mat: marbleMat, pos: [0.8, -4.2, -3] },
    ];

    satelliteConfigs.forEach((config, idx) => {
      const mesh = new THREE.Mesh(config.geom, config.mat);
      mesh.position.set(config.pos[0], config.pos[1], config.pos[2]);
      worldGroup.add(mesh);
      floatingObjects.push({
        mesh,
        baseY: config.pos[1],
        speedY: 0.7 + (idx % 3) * 0.3,
        rotSpeedX: 0.004 + (idx % 2) * 0.003,
        rotSpeedY: 0.006 + (idx % 3) * 0.003,
        phase: idx * 1.4,
      });
    });

    // 3. Golden Dust & Ambient Light Specks
    const isMobile = window.innerWidth < 768;
    const particleCount = isMobile ? 180 : 450;
    const particlePositions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);

    const cGold = new THREE.Color(0xd5c3aa);
    const cAlabaster = new THREE.Color(0xf5f3ee);
    const cMist = new THREE.Color(0x9ca9bb);

    for (let i = 0; i < particleCount; i++) {
      particlePositions[i * 3] = (Math.random() - 0.5) * 36;
      particlePositions[i * 3 + 1] = (Math.random() - 0.5) * 26;
      particlePositions[i * 3 + 2] = (Math.random() - 0.5) * 20 - 2;

      const pick = Math.random();
      const col = pick < 0.5 ? cGold : pick < 0.85 ? cAlabaster : cMist;
      particleColors[i * 3] = col.r;
      particleColors[i * 3 + 1] = col.g;
      particleColors[i * 3 + 2] = col.b;
    }

    const particleGeom = new THREE.BufferGeometry();
    particleGeom.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particleGeom.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));

    // Procedural soft glowing dust particle
    const particleCanvas = document.createElement('canvas');
    particleCanvas.width = 32;
    particleCanvas.height = 32;
    const pctx = particleCanvas.getContext('2d');
    if (pctx) {
      const grad = pctx.createRadialGradient(16, 16, 0, 16, 16, 16);
      grad.addColorStop(0, 'rgba(245, 240, 230, 0.95)');
      grad.addColorStop(0.35, 'rgba(213, 195, 170, 0.7)');
      grad.addColorStop(0.8, 'rgba(213, 195, 170, 0.15)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      pctx.fillStyle = grad;
      pctx.fillRect(0, 0, 32, 32);
    }
    const particleTexture = new THREE.CanvasTexture(particleCanvas);
    particleTexture.colorSpace = THREE.SRGBColorSpace;

    const particleMat = new THREE.PointsMaterial({
      size: isMobile ? 0.14 : 0.2,
      map: particleTexture,
      transparent: true,
      vertexColors: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const particles = new THREE.Points(particleGeom, particleMat);
    worldGroup.add(particles);

    // 4. Parallax & Mouse/Touch Interaction
    const targetParallax = { x: 0, y: 0 };
    const currentParallax = { x: 0, y: 0 };

    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      let clientX = 0;
      let clientY = 0;
      if ('touches' in e && e.touches.length > 0) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      } else if ('clientX' in e) {
        clientX = (e as MouseEvent).clientX;
        clientY = (e as MouseEvent).clientY;
      }
      const normX = (clientX / window.innerWidth) * 2 - 1;
      const normY = -(clientY / window.innerHeight) * 2 + 1;
      targetParallax.x = normX * 0.75;
      targetParallax.y = normY * 0.45;
    };

    window.addEventListener('mousemove', handlePointerMove, { passive: true });
    window.addEventListener('touchmove', handlePointerMove, { passive: true });

    // Handle Resize
    const handleResize = () => {
      if (!renderer) return;
      const width = window.innerWidth;
      const height = window.innerHeight;
      camera.aspect = width / height;

      if (width < 768) {
        centralCluster.position.set(0, 1.2, -2);
        centralCluster.scale.set(0.65, 0.65, 0.65);
      } else if (width < 1024) {
        centralCluster.position.set(2.2, 0.8, -1);
        centralCluster.scale.set(0.85, 0.85, 0.85);
      } else {
        centralCluster.position.set(3.6, 0.4, 0);
        centralCluster.scale.set(1.05, 1.05, 1.05);
      }

      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
      renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 1.75));
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animationFrameId = 0;
    const clock = new THREE.Clock();

    function renderFrame() {
      const delta = Math.min(clock.getDelta(), 0.1);
      const elapsedTime = clock.getElapsedTime();

      if (!prefersReducedMotion) {
        currentParallax.x = THREE.MathUtils.damp(currentParallax.x, targetParallax.x, 3.2, delta);
        currentParallax.y = THREE.MathUtils.damp(currentParallax.y, targetParallax.y, 3.2, delta);
        worldGroup.position.x = currentParallax.x;
        worldGroup.position.y = currentParallax.y;

        camera.rotation.y = -currentParallax.x * 0.07;
        camera.rotation.x = currentParallax.y * 0.07;

        torusKnot.rotation.x += 0.3 * delta;
        torusKnot.rotation.y += 0.45 * delta;
        outerCage.rotation.x -= 0.15 * delta;
        outerCage.rotation.y -= 0.22 * delta;
        ringMesh.rotation.z += 0.25 * delta;

        floatingObjects.forEach((obj) => {
          obj.mesh.position.y = obj.baseY + Math.sin(elapsedTime * obj.speedY + obj.phase) * 0.3;
          obj.mesh.rotation.x += obj.rotSpeedX;
          obj.mesh.rotation.y += obj.rotSpeedY;
        });

        particles.rotation.y += 0.02 * delta;
        particles.rotation.x += 0.01 * delta;
      }

      renderer.render(scene, camera);
      animationFrameId = requestAnimationFrame(renderFrame);
    }

    animationFrameId = requestAnimationFrame(renderFrame);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('resize', handleResize);

      try {
        knotGeom.dispose();
        cageGeom.dispose();
        cageMat.dispose();
        ringGeom.dispose();
        antiqueGoldMat.dispose();
        marbleMat.dispose();
        particleGeom.dispose();
        particleMat.dispose();
        particleTexture.dispose();
        satelliteConfigs.forEach((c) => {
          c.geom.dispose();
          c.mat.dispose();
        });
        renderer.dispose();
        if (renderer.domElement && container.contains(renderer.domElement)) {
          container.removeChild(renderer.domElement);
        }
      } catch (err) {
        console.warn('Error during Three.js cleanup:', err);
      }
    };
  }, []);

  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 pointer-events-none z-0 overflow-hidden"
    >
      {webglSupported ? (
        <div ref={mountRef} className="w-full h-full" />
      ) : (
        /* CSS Animated Fallback */
        <div className="w-full h-full relative bg-[#14171d] overflow-hidden">
          <div className="absolute -top-40 -right-40 w-96 h-96 bg-[#d5c3aa]/10 rounded-full blur-[130px]" />
          <div className="absolute top-1/3 -left-32 w-80 h-80 bg-slate-700/20 rounded-full blur-[100px]" />
          <div className="absolute bottom-10 right-1/4 w-96 h-96 bg-[#c4b197]/10 rounded-full blur-[140px]" />
        </div>
      )}
    </div>
  );
}
