import { useState, FormEvent } from 'react';
import { Mail, Send, Copy, Check, Sparkles, MessageSquare, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ContactSection() {
  const EMAIL = 'ab40510245@gmail.com';

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [copied, setCopied] = useState(false);
  const [submissionStatus, setSubmissionStatus] = useState<{
    status: 'idle' | 'success' | 'error';
    message?: string;
    mailtoUrl?: string;
  }>({ status: 'idle' });

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) errs.name = 'Please provide your name.';
    if (!formData.email.trim()) {
      errs.email = 'Please provide your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      errs.email = 'Please enter a valid email address.';
    }
    if (!formData.subject.trim()) errs.subject = 'Please provide a subject.';
    if (!formData.message.trim()) errs.message = 'Please provide your message.';
    return errs;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setErrors({});

    const emailSubject = encodeURIComponent(`[Portfolio Inquiry] ${formData.subject}`);
    const emailBody = encodeURIComponent(
      `Hello Ankit,\n\n${formData.message}\n\n---\nSender: ${formData.name}\nContact Email: ${formData.email}`
    );
    const mailtoLink = `mailto:${EMAIL}?subject=${emailSubject}&body=${emailBody}`;

    window.location.href = mailtoLink;

    setSubmissionStatus({
      status: 'success',
      message:
        'Your message has been formatted and opened in your email client. You can also copy the details below or email directly to ab40510245@gmail.com.',
      mailtoUrl: mailtoLink,
    });
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(EMAIL);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <motion.section
      id="contact"
      initial={{ opacity: 0, y: 36 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15 }}
      transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      className="relative py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10"
    >
      
      {/* Section Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-col items-center text-center mb-16"
      >
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-marble text-[#d5c3aa] mb-2">
          <MessageSquare className="w-3.5 h-3.5" />
          <span>Connect &amp; Collaborate</span>
        </div>
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#f5f3ef]">
          Let's Build Something Great
        </h2>
        <p className="text-sm sm:text-base text-slate-300 max-w-xl mt-4 leading-relaxed">
          Have an idea, project, or opportunity? I'd love to hear from you.
        </p>
        <div className="w-12 h-1 bg-[#d5c3aa] rounded-full mt-4 opacity-75" />
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* Left Column: Direct Contact Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-5 space-y-6"
        >
          <div className="p-8 sm:p-10 rounded-[32px] marble-card relative overflow-hidden flex flex-col justify-between h-full">
            
            {/* Subtle botanical line accent */}
            <svg
              className="absolute -top-4 -right-4 w-40 h-40 text-[#d5c3aa]/10 stroke-current pointer-events-none"
              viewBox="0 0 100 100"
              fill="none"
              strokeWidth="1"
            >
              <circle cx="50" cy="50" r="45" strokeDasharray="3 3" />
              <path d="M20 80 Q 50 30 80 20" />
            </svg>

            <div className="space-y-6 relative z-10">
              <div className="w-12 h-12 rounded-full border border-[#d5c3aa]/40 bg-[#161a22] flex items-center justify-center text-[#d5c3aa] shadow-inner">
                <Mail className="w-6 h-6" />
              </div>

              <div>
                <span className="text-[10px] font-mono uppercase tracking-marble text-[#d5c3aa]">
                  Direct Inquiries
                </span>
                <h3 className="text-xl sm:text-2xl font-bold text-[#f5f3ef] mt-1.5 tracking-wide">
                  ab40510245@gmail.com
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 mt-2.5 leading-relaxed">
                  Feel free to reach out directly regarding technical discussions, web development
                  initiatives, or prospective collaborations.
                </p>
              </div>

              {/* Action Buttons: Direct Mailto & Copy */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <a
                  href={`mailto:${EMAIL}`}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3 text-xs font-semibold btn-marble-sand tracking-wider"
                >
                  <Mail className="w-4 h-4 text-[#171a21]" />
                  <span>Email Me Directly</span>
                </a>

                <button
                  type="button"
                  onClick={handleCopyEmail}
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-medium btn-marble-outline tracking-wider"
                  aria-label="Copy email address to clipboard"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 text-[#d5c3aa]" />
                      <span className="text-[#d5c3aa]">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-slate-400" />
                      <span>Copy Email</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Availability & Ethics Strip */}
            <div className="mt-8 pt-6 border-t border-white/[0.08] space-y-2 relative z-10">
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <Sparkles className="w-4 h-4 text-[#d5c3aa]" />
                <span>Responsive to emails within 24–48 hours</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Open to discussions with engineering leads, product founders, and design teams.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Right Column: Contact Form */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.65, delay: 0.28, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-7 p-8 sm:p-10 rounded-[32px] marble-card"
        >
          <form onSubmit={handleSubmit} noValidate className="space-y-5">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* Name Field */}
              <div>
                <label htmlFor="contact-name" className="block text-xs font-medium tracking-wide text-slate-300 mb-2">
                  Your Name <span className="text-[#d5c3aa]">*</span>
                </label>
                <input
                  id="contact-name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Alex Morgan"
                  className={`w-full px-4 py-3 rounded-xl bg-[#151820] border text-xs text-white placeholder-slate-500 focus:outline-none transition-colors ${
                    errors.name ? 'border-rose-500/70' : 'border-[#d5c3aa]/20 focus:border-[#d5c3aa]'
                  }`}
                />
                {errors.name && (
                  <p className="mt-1.5 text-[11px] text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.name}</span>
                  </p>
                )}
              </div>

              {/* Email Field */}
              <div>
                <label htmlFor="contact-email" className="block text-xs font-medium tracking-wide text-slate-300 mb-2">
                  Your Email <span className="text-[#d5c3aa]">*</span>
                </label>
                <input
                  id="contact-email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="alex@example.com"
                  className={`w-full px-4 py-3 rounded-xl bg-[#151820] border text-xs text-white placeholder-slate-500 focus:outline-none transition-colors ${
                    errors.email ? 'border-rose-500/70' : 'border-[#d5c3aa]/20 focus:border-[#d5c3aa]'
                  }`}
                />
                {errors.email && (
                  <p className="mt-1.5 text-[11px] text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.email}</span>
                  </p>
                )}
              </div>
            </div>

            {/* Subject Field */}
            <div>
              <label htmlFor="contact-subject" className="block text-xs font-medium tracking-wide text-slate-300 mb-2">
                Subject <span className="text-[#d5c3aa]">*</span>
              </label>
              <input
                id="contact-subject"
                type="text"
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                placeholder="Collaboration, project inquiry, or quick hello"
                className={`w-full px-4 py-3 rounded-xl bg-[#151820] border text-xs text-white placeholder-slate-500 focus:outline-none transition-colors ${
                  errors.subject ? 'border-rose-500/70' : 'border-[#d5c3aa]/20 focus:border-[#d5c3aa]'
                }`}
              />
              {errors.subject && (
                <p className="mt-1.5 text-[11px] text-rose-400 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  <span>{errors.subject}</span>
                </p>
              )}
            </div>

            {/* Message Field */}
            <div>
              <label htmlFor="contact-message" className="block text-xs font-medium tracking-wide text-slate-300 mb-2">
                Message <span className="text-[#d5c3aa]">*</span>
              </label>
              <textarea
                id="contact-message"
                rows={5}
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="Share your goals, project timeline, or ideas..."
                className={`w-full px-4 py-3 rounded-xl bg-[#151820] border text-xs text-white placeholder-slate-500 focus:outline-none transition-colors resize-none ${
                  errors.message ? 'border-rose-500/70' : 'border-[#d5c3aa]/20 focus:border-[#d5c3aa]'
                }`}
              />
              {errors.message && (
                <p className="mt-1.5 text-[11px] text-rose-400 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  <span>{errors.message}</span>
                </p>
              )}
            </div>

            {/* Submission Status Notice */}
            {submissionStatus.status === 'success' && (
              <div className="p-4 rounded-xl bg-[#14171d] border border-[#d5c3aa]/40 text-xs text-[#d5c3aa] space-y-2">
                <div className="flex items-center gap-2 font-semibold text-[#f5f3ef]">
                  <Check className="w-4 h-4 text-[#d5c3aa]" />
                  <span>Email Client Triggered</span>
                </div>
                <p className="leading-relaxed text-slate-300">{submissionStatus.message}</p>
              </div>
            )}

            {/* Send Button */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
              <p className="text-[11px] text-slate-400">
                Direct mailto dispatch (no third-party tracking or credentials required)
              </p>

              <button
                type="submit"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3 text-xs font-semibold btn-marble-sand cursor-pointer tracking-wider"
              >
                <Send className="w-3.5 h-3.5 text-[#171a21]" />
                <span>Send Message</span>
              </button>
            </div>

          </form>
        </motion.div>

      </div>

    </motion.section>
  );
}
