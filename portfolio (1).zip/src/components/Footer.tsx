import { ArrowUp, Mail } from 'lucide-react';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative z-10 border-t border-[#d5c3aa]/15 bg-[#12141a]/95 backdrop-blur-md py-16 px-4 sm:px-6 lg:px-8 overflow-hidden">
      
      {/* Subtle background botanical line flourish */}
      <svg
        className="absolute right-12 bottom-0 w-44 h-44 text-[#d5c3aa]/5 stroke-current pointer-events-none"
        viewBox="0 0 100 100"
        fill="none"
      >
        <circle cx="50" cy="50" r="46" strokeDasharray="2 3" />
        <path d="M20 90 Q 60 50 80 10" strokeWidth="1" />
      </svg>

      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Top Aesthetic Banner from Reference Image ("Thank you for watching") */}
        <div className="flex flex-col sm:flex-row items-center justify-between pb-8 border-b border-white/[0.06] gap-4 text-center sm:text-left">
          <div className="space-y-1">
            <span className="text-xl sm:text-2xl font-light text-[#f5f3ef] tracking-wide block">
              Thank you for exploring
            </span>
            <span className="text-[11px] uppercase tracking-marble text-[#d5c3aa]">
              Marble Archive · Identity Series
            </span>
          </div>

          <button
            type="button"
            onClick={scrollToTop}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-xs btn-marble-outline tracking-wider"
            aria-label="Back to top"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5 text-[#d5c3aa]" />
          </button>
        </div>

        {/* Footer Details */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          
          {/* Brand & Slogan */}
          <div className="flex flex-col items-center md:items-start space-y-1.5 text-center md:text-left">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-full border border-[#d5c3aa]/40 bg-[#161a22] flex items-center justify-center text-[11px] font-bold text-[#d5c3aa]">
                AB
              </div>
              <span className="font-semibold text-[#f5f3ef] tracking-marble uppercase text-sm">
                Ankit Baghel
              </span>
            </div>
            <p className="text-xs text-slate-400 tracking-wide">
              Designed with curiosity and built for the future.
            </p>
          </div>

          {/* Center: Direct Email Link */}
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <Mail className="w-4 h-4 text-[#d5c3aa]" />
            <a
              href="mailto:ab40510245@gmail.com"
              className="hover:text-[#d5c3aa] transition-colors underline-offset-4 hover:underline tracking-wide"
            >
              ab40510245@gmail.com
            </a>
          </div>

          {/* Right: Copyright */}
          <div className="text-xs text-slate-500 tracking-wider">
            &copy; {currentYear} Ankit Baghel. All rights reserved.
          </div>

        </div>

      </div>
    </footer>
  );
}
