import { ArrowDown, FolderGit2, Mail } from 'lucide-react';
import { motion } from 'framer-motion';

export default function HeroSection() {
  const scrollTo = (selector: string) => {
    const el = document.querySelector(selector);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-28 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden"
    >
      {/* Background atmospheric mist and subtle mountain silhouette */}
      <div className="absolute inset-0 pointer-events-none opacity-25">
        <svg
          className="absolute bottom-0 left-0 right-0 w-full h-96 text-slate-700/30"
          viewBox="0 0 1440 320"
          preserveAspectRatio="none"
          fill="currentColor"
        >
          <path d="M0,224L60,208C120,192,240,160,360,165.3C480,171,600,213,720,208C840,203,960,149,1080,138.7C1200,128,1320,160,1380,176L1440,192L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z" />
        </svg>
      </div>

      <div className="max-w-6xl mx-auto w-full z-10">
        
        {/* Main Hero Card Plate (Matching the rounded dark card in the reference image) */}
        <div className="relative rounded-[32px] p-8 sm:p-12 lg:p-16 marble-card overflow-hidden">
          
          {/* Subtle botanical line art illustration in top right */}
          <svg
            className="absolute -top-6 -right-6 w-56 h-56 text-[#d5c3aa]/20 pointer-events-none stroke-current"
            viewBox="0 0 100 100"
            fill="none"
            strokeWidth="0.75"
          >
            <path d="M50 95 C 45 60, 65 35, 90 20" />
            <path d="M58 75 C 65 68, 72 70, 75 75 C 70 79, 62 80, 58 75" />
            <path d="M63 56 C 72 48, 80 50, 83 57 C 77 61, 68 62, 63 56" />
            <path d="M72 38 C 82 32, 90 35, 92 42 C 85 45, 77 44, 72 38" />
            <circle cx="50" cy="50" r="42" strokeDasharray="2 3" opacity="0.4" />
          </svg>

          {/* Top Series Archive Tag */}
          <div className="flex items-center justify-between mb-8 pb-4 border-b border-white/[0.06]">
            <div className="flex items-center gap-3">
              <span className="text-[11px] font-medium tracking-marble uppercase text-[#d5c3aa]">
                Ankit Baghel Archive
              </span>
              <span className="text-[10px] text-slate-500 tracking-wider">
                Identity Series Vol. 01
              </span>
            </div>
            <div className="hidden sm:flex items-center gap-2 text-[10px] text-slate-400 font-mono tracking-wider">
              <span>EST. 2026</span>
              <span>·</span>
              <span className="text-[#d5c3aa]">FOLIO EDITION</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Content Area with vertical pagination dots */}
            <div className="lg:col-span-7 flex items-start gap-6">
              
              {/* 5 Vertical Pagination Dots (Signature detail from reference image) */}
              <div className="hidden sm:flex flex-col items-center gap-2.5 pt-4 text-slate-600">
                <span className="w-1.5 h-1.5 rounded-full bg-[#d5c3aa] shadow-[0_0_6px_rgba(213,195,170,0.8)]" />
                <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
              </div>

              {/* Text Hierarchy */}
              <div className="space-y-6 flex-1">
                
                {/* Introductory Kicker */}
                <div className="text-xs font-semibold uppercase tracking-marble text-[#d5c3aa]">
                  HELLO, I'M
                </div>

                {/* Main Heading: "The" + "Ankit Baghel" (Stacked style from reference) */}
                <div className="space-y-1">
                  <span className="block text-2xl sm:text-3xl font-light tracking-wide text-slate-300">
                    The
                  </span>
                  <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-[#f5f3ef] leading-[1.05]">
                    Ankit Baghel
                  </h1>
                </div>

                {/* Professional Headline */}
                <p className="text-base sm:text-lg font-medium text-[#d5c3aa] tracking-wide">
                  Creative Digital Explorer | Future IT Professional
                </p>

                {/* Identity Metadata Block (Matching reference format) */}
                <div className="text-xs sm:text-sm text-slate-300 space-y-1 bg-black/20 p-4 rounded-xl border border-white/[0.05]">
                  <p className="font-medium text-[#f5f3ef]">
                    Ankit Baghel — The Explorer.
                  </p>
                  <p className="text-slate-400">
                    Exploring technology, building digital experiences, and turning ideas into reality.
                  </p>
                  <p className="text-[11px] text-slate-500 font-mono pt-1">
                    Identity No. AB-2026 / Origin: Global / Focus: Web &amp; AI
                  </p>
                </div>

                {/* Action Buttons ("view identity" champagne sand button + outline) */}
                <div className="flex flex-wrap items-center gap-4 pt-2">
                  <button
                    type="button"
                    onClick={() => scrollTo('#projects')}
                    className="inline-flex items-center justify-center gap-2 px-7 py-3 text-xs font-semibold btn-marble-sand cursor-pointer tracking-wider"
                  >
                    <FolderGit2 className="w-4 h-4 text-[#171a21]" />
                    <span>Explore My Work</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => scrollTo('#contact')}
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 text-xs font-medium btn-marble-outline cursor-pointer tracking-wider"
                  >
                    <Mail className="w-4 h-4 text-[#d5c3aa]" />
                    <span>Contact Me</span>
                  </button>
                </div>

              </div>

            </div>

            {/* Right Column: Classical Sculpture Medallion (from reference image) */}
            <div className="lg:col-span-5 flex justify-center items-center">
              <div className="relative w-64 h-64 sm:w-80 sm:h-80 flex items-center justify-center">
                
                {/* Thin celestial gold crescent ring */}
                <div className="absolute inset-0 rounded-full border border-[#d5c3aa]/40 -rotate-12 pointer-events-none" />
                <div className="absolute inset-3 rounded-full border border-white/10 pointer-events-none" />
                <div className="absolute -top-4 -right-2 w-16 h-16 rounded-full bg-[#d5c3aa]/10 blur-xl pointer-events-none" />

                {/* Circular Medallion with classical alabaster marble aesthetic */}
                <div className="w-56 h-56 sm:w-72 sm:h-72 rounded-full overflow-hidden bg-gradient-to-b from-[#2a303c] to-[#12151b] border-2 border-[#d5c3aa]/50 shadow-2xl relative flex items-center justify-center p-3">
                  
                  {/* Subtle alpine mist & mountain background */}
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-600/40 via-[#1c212a] to-[#0f1217]" />
                  
                  {/* Alabaster Classical Bust Silhouette / Monogram Art */}
                  <div className="relative z-10 flex flex-col items-center justify-center text-center">
                    <div className="w-24 h-24 rounded-full border border-[#d5c3aa]/60 flex items-center justify-center bg-[#181b22]/90 shadow-inner mb-3">
                      <span className="font-classical text-4xl text-[#d5c3aa] tracking-widest pl-1">
                        AB
                      </span>
                    </div>
                    <span className="text-[11px] uppercase tracking-marble text-[#d5c3aa] font-semibold">
                      Marble Identity
                    </span>
                    <span className="text-[10px] text-slate-400 tracking-wider mt-0.5">
                      Future IT Professional
                    </span>
                  </div>

                  {/* Botanical Leaf Overlay SVG */}
                  <svg
                    className="absolute bottom-2 right-4 w-28 h-28 text-[#d5c3aa]/40 stroke-current pointer-events-none"
                    viewBox="0 0 100 100"
                    fill="none"
                    strokeWidth="1.2"
                  >
                    <path d="M20 90 C 40 70, 60 50, 85 20" />
                    <path d="M35 70 C 42 62, 50 64, 52 70 C 47 74, 40 75, 35 70" />
                    <path d="M52 50 C 60 42, 68 44, 70 51 C 64 55, 57 56, 52 50" />
                    <path d="M68 32 C 76 25, 84 27, 86 34 C 80 37, 73 37, 68 32" />
                  </svg>
                </div>

                {/* Subtitle tag below circle */}
                <div className="absolute -bottom-4 bg-[#14171d] px-4 py-1 rounded-full border border-[#d5c3aa]/30 text-[10px] tracking-marble text-[#d5c3aa] uppercase shadow-lg">
                  Archive No. 001
                </div>

              </div>
            </div>

          </div>

        </div>

      </div>

      {/* Subtle Scroll Indicator */}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-1 opacity-70 hover:opacity-100 transition-opacity">
        <button
          onClick={() => scrollTo('#about')}
          className="flex flex-col items-center gap-1 text-[10px] tracking-marble uppercase text-slate-400 hover:text-[#d5c3aa] focus:outline-none cursor-pointer"
          aria-label="Scroll to About Me section"
        >
          <span>Scroll</span>
          <ArrowDown className="w-3.5 h-3.5 animate-bounce text-[#d5c3aa]" />
        </button>
      </div>

    </section>
  );
}
