import { useState } from 'react';
import {
  FileCode,
  Terminal,
  Atom,
  Binary,
  Layout,
  Brain,
  Palette,
  GitBranch,
  Layers,
  ArrowUpRight
} from 'lucide-react';
import { motion } from 'framer-motion';
import type { SkillItem } from '../types';

export const SKILLS_DATA: SkillItem[] = [
  {
    id: 'html-css',
    name: 'HTML & CSS',
    category: 'core',
    categoryLabel: 'Core Foundations',
    description: 'Semantic markup structure, modern CSS flexbox/grid layout systems, responsive variables, and transitions.',
    iconName: 'FileCode',
  },
  {
    id: 'javascript',
    name: 'JavaScript',
    category: 'core',
    categoryLabel: 'Scripting & Logic',
    description: 'ES6+ syntax, asynchronous programming, DOM event architecture, and functional programming concepts.',
    iconName: 'Terminal',
  },
  {
    id: 'react',
    name: 'React',
    category: 'frameworks',
    categoryLabel: 'Frontend Architecture',
    description: 'Component lifecycles, custom hooks, reactive state flows, modular component composition, and virtual DOM.',
    iconName: 'Atom',
  },
  {
    id: 'python',
    name: 'Python',
    category: 'frameworks',
    categoryLabel: 'Backend & Scripting',
    description: 'General-purpose programming, automation scripts, data handling, and exploring computational backends.',
    iconName: 'Binary',
  },
  {
    id: 'responsive-design',
    name: 'Responsive Web Design',
    category: 'design',
    categoryLabel: 'Cross-Device UX',
    description: 'Mobile-first viewport composition, fluid typography, touch ergonomics, and media query discipline.',
    iconName: 'Layout',
  },
  {
    id: 'ai-concepts',
    name: 'Artificial Intelligence',
    category: 'frameworks',
    categoryLabel: 'Emerging Tech',
    description: 'Understanding LLM concepts, multimodal AI interfaces, prompt engineering, and intelligent app design.',
    iconName: 'Brain',
  },
  {
    id: 'ui-ux',
    name: 'UI/UX Design',
    category: 'design',
    categoryLabel: 'Interface Craft',
    description: 'Information hierarchy, glassmorphism aesthetics, color contrast compliance, and user-centered design patterns.',
    iconName: 'Palette',
  },
  {
    id: 'git-github',
    name: 'Git & GitHub',
    category: 'tools',
    categoryLabel: 'Version Control',
    description: 'Branch management, commit hygiene, collaborative code sharing, repositories, and GitHub workflow.',
    iconName: 'GitBranch',
  },
];

const renderSkillIcon = (iconName: string) => {
  switch (iconName) {
    case 'FileCode':
      return <FileCode className="w-6 h-6 text-[#d5c3aa]" />;
    case 'Terminal':
      return <Terminal className="w-6 h-6 text-[#e8dccb]" />;
    case 'Atom':
      return <Atom className="w-6 h-6 text-[#d5c3aa]" />;
    case 'Binary':
      return <Binary className="w-6 h-6 text-[#c4b197]" />;
    case 'Layout':
      return <Layout className="w-6 h-6 text-[#d5c3aa]" />;
    case 'Brain':
      return <Brain className="w-6 h-6 text-[#e8dccb]" />;
    case 'Palette':
      return <Palette className="w-6 h-6 text-[#c4b197]" />;
    case 'GitBranch':
      return <GitBranch className="w-6 h-6 text-[#d5c3aa]" />;
    default:
      return <Layers className="w-6 h-6 text-[#d5c3aa]" />;
  }
};

export default function SkillsSection() {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All Learning Interests' },
    { id: 'core', label: 'Core Foundations' },
    { id: 'frameworks', label: 'Frameworks & Logic' },
    { id: 'design', label: 'Design & UX' },
    { id: 'tools', label: 'Tools & Versioning' },
  ];

  const filteredSkills =
    activeCategory === 'all'
      ? SKILLS_DATA
      : SKILLS_DATA.filter((s) => s.category === activeCategory);

  return (
    <motion.section
      id="skills"
      initial={{ opacity: 0, y: 36 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15 }}
      transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      className="relative py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10"
    >
      
      {/* Section Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-col items-center text-center mb-12"
      >
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-marble text-[#d5c3aa] mb-2">
          <Layers className="w-3.5 h-3.5" />
          <span>Curated Disciplines &amp; Craft</span>
        </div>
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#f5f3ef]">
          Skills &amp; Learning Interests
        </h2>
        <p className="text-sm sm:text-base text-slate-300 max-w-2xl mt-4 leading-relaxed">
          Technologies and domains I actively study, experiment with, and cultivate as an aspiring IT
          professional.
        </p>
        <div className="w-12 h-1 bg-[#d5c3aa] rounded-full mt-4 opacity-75" />
      </motion.div>

      {/* Interactive Category Filter Tabs */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-wrap items-center justify-center gap-2 mb-10"
      >
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-5 py-2 text-xs tracking-wider rounded-full transition-all duration-200 cursor-pointer ${
              activeCategory === cat.id
                ? 'bg-[#d5c3aa] text-[#171a21] font-semibold shadow-md shadow-black/30'
                : 'bg-[#1a1e26] text-slate-300 hover:text-white hover:bg-[#232833] border border-white/[0.06]'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </motion.div>

      {/* Skills Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredSkills.map((skill, idx) => (
          <motion.div
            key={skill.id}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, delay: 0.15 + (idx % 4) * 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="group relative p-6 rounded-2xl marble-card flex flex-col justify-between hover:border-[#d5c3aa]/40 transition-all duration-300 hover:-translate-y-1"
          >
            <div>
              {/* Card Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-[#161920] border border-[#d5c3aa]/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                  {renderSkillIcon(skill.iconName)}
                </div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#d5c3aa] bg-[#d5c3aa]/10 px-2.5 py-1 rounded-md border border-[#d5c3aa]/20">
                  {skill.categoryLabel}
                </span>
              </div>

              {/* Title */}
              <h3 className="text-lg font-bold text-[#f5f3ef] group-hover:text-[#d5c3aa] transition-colors mb-2 tracking-wide">
                {skill.name}
              </h3>

              {/* Description */}
              <p className="text-xs text-slate-300 leading-relaxed">
                {skill.description}
              </p>
            </div>

            {/* Bottom Status */}
            <div className="mt-5 pt-3.5 border-t border-white/[0.06] flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#d5c3aa]" />
                <span className="tracking-wide">Learning Interest</span>
              </span>
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-[#d5c3aa] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
            </div>
          </motion.div>
        ))}
      </div>

      {/* Footnote on Skill Philosophy */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="mt-12 text-center text-xs text-slate-400 flex items-center justify-center gap-2 tracking-wide"
      >
        <span className="w-1.5 h-1.5 rounded-full bg-[#d5c3aa]" />
        <span>Focused on building robust fundamentals and creating hands-on projects.</span>
      </motion.div>

    </motion.section>
  );
}
