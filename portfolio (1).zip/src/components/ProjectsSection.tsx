import { useState } from 'react';
import { ExternalLink, Code2, Sparkles, FolderGit2 } from 'lucide-react';
import { motion } from 'framer-motion';
import type { ProjectItem } from '../types';
import ConceptModal from './ConceptModal';

export const PROJECTS_DATA: ProjectItem[] = [
  {
    id: 'ai-assistant',
    title: 'AI Assistant Website',
    subtitle: 'Conversational Intelligence Concept',
    description: 'A concept for an AI-powered assistant with a clean conversational interface.',
    image: '/src/assets/images/project_ai_assistant_1793033265548.jpg',
    tags: ['React', 'TypeScript', 'Conversational UI', 'Web Audio API', 'Tailwind CSS'],
    type: 'Concept Prototype',
    features: [
      'Interactive voice waveform audio state visualizer',
      'Glassmorphic dark interface with marble and champagne glows',
      'Markdown rendering & code block syntax display',
      'Session memory & context history management architecture'
    ],
    conceptRationale: 'Explores frictionless conversational ergonomics and human-AI interface interaction patterns.'
  },
  {
    id: 'video-downloader',
    title: 'Video Downloader Interface',
    subtitle: 'Media Utility & Transcoding Concept',
    description: 'A responsive video utility interface with quality-selection concepts.',
    image: '/src/assets/images/project_video_downloader_1793033266043.jpg',
    tags: ['Responsive Web Design', 'JavaScript', 'Media Streams', 'Utility UI', 'CSS Grid'],
    type: 'Concept Prototype',
    features: [
      'Multi-resolution preset selection (4K UHD to 720p)',
      'Real-time bitrate & bandwidth performance charts',
      'Custom media player viewport with dark ambient backdrop',
      'Batch download queue concept & format transcode selector'
    ],
    conceptRationale: 'Designed to solve complex media utility controls through accessible, high-performance UI composition.'
  },
  {
    id: 'food-scanner',
    title: 'Smart Food Label Scanner',
    subtitle: 'Computer Vision & Nutrition UI Concept',
    description: 'A concept for scanning food labels and presenting ingredient information.',
    image: '/src/assets/images/project_food_scanner_1793033266333.jpg',
    tags: ['Mobile UX', 'Computer Vision Concept', 'Health Tech', 'Data Visualization', 'React'],
    type: 'Concept Prototype',
    features: [
      'Holographic overlay HUD for packaging barcode recognition',
      'Nutritional macro breakdowns (Protein, Carbs, Healthy Fats)',
      'Allergen alert flagging and clean ingredient parsing',
      'Mobile-optimized touch layout and high-contrast typography'
    ],
    conceptRationale: 'Bridges nutrition science and consumer packaging through instant visual breakdown analysis.'
  }
];

export default function ProjectsSection() {
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [modalMode, setModalMode] = useState<'demo' | 'code' | null>(null);

  const openModal = (project: ProjectItem, mode: 'demo' | 'code') => {
    setSelectedProject(project);
    setModalMode(mode);
  };

  const closeModal = () => {
    setSelectedProject(null);
    setModalMode(null);
  };

  return (
    <motion.section
      id="projects"
      initial={{ opacity: 0, y: 36 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15 }}
      transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      className="relative py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10"
    >
      
      {/* Section Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-col items-center text-center mb-16"
      >
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-marble text-[#d5c3aa] mb-2">
          <FolderGit2 className="w-3.5 h-3.5" />
          <span>Curated Works &amp; Series</span>
        </div>
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#f5f3ef]">
          Featured Projects
        </h2>
        <p className="text-sm sm:text-base text-slate-300 max-w-2xl mt-4 leading-relaxed">
          Interactive concepts and design prototypes demonstrating my exploration in user interface
          design, modern web standards, and digital product architecture.
        </p>
        <div className="w-12 h-1 bg-[#d5c3aa] rounded-full mt-4 opacity-75" />
      </motion.div>

      {/* Project Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 items-stretch">
        {PROJECTS_DATA.map((project, idx) => (
          <motion.div
            key={project.id}
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 + idx * 0.12, ease: [0.16, 1, 0.3, 1] }}
            className="group rounded-[28px] marble-card overflow-hidden flex flex-col justify-between hover:border-[#d5c3aa]/40 transition-all duration-300 hover:-translate-y-1.5"
          >
            {/* Visual Thumbnail Container */}
            <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-950">
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1f232b] via-transparent to-transparent opacity-80" />
              
              {/* Concept Label */}
              <div className="absolute top-3.5 left-3.5">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold bg-[#171a21]/90 text-[#d5c3aa] border border-[#d5c3aa]/40 backdrop-blur-md shadow-md tracking-wide">
                  <Sparkles className="w-3 h-3 text-[#d5c3aa]" />
                  <span>The Prototype</span>
                </span>
              </div>
            </div>

            {/* Card Body */}
            <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between space-y-4">
              <div>
                <span className="text-[10px] tracking-marble uppercase text-[#d5c3aa] block mb-1">
                  {project.subtitle}
                </span>
                <h3 className="text-xl font-bold text-[#f5f3ef] group-hover:text-[#d5c3aa] transition-colors tracking-wide">
                  {project.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 mt-2.5 leading-relaxed">
                  {project.description}
                </p>
              </div>

              {/* Technology Tags */}
              <div className="pt-2">
                <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-400">
                  {project.tags.map((tag, i) => (
                    <span key={tag} className="flex items-center">
                      <span className="text-slate-300 font-mono text-[11px] hover:text-[#d5c3aa] transition-colors">
                        {tag}
                      </span>
                      {i < project.tags.length - 1 && (
                        <span className="text-slate-600 mx-1.5" aria-hidden="true">
                          ·
                        </span>
                      )}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Card Actions */}
            <div className="p-6 sm:p-7 pt-0 border-t border-white/[0.06] mt-auto">
              <div className="grid grid-cols-2 gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => openModal(project, 'demo')}
                  className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 text-xs btn-marble-sand cursor-pointer tracking-wider"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-[#171a21]" />
                  <span>Live Demo</span>
                </button>

                <button
                  type="button"
                  onClick={() => openModal(project, 'code')}
                  className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 text-xs btn-marble-outline cursor-pointer tracking-wider"
                >
                  <Code2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>Source Code</span>
                </button>
              </div>

              <div className="mt-3 text-center text-[10px] tracking-wide text-slate-400">
                <span>Click to inspect concept architecture &amp; mockup</span>
              </div>
            </div>

          </motion.div>
        ))}
      </div>

      {/* Concept Disclaimer Strip */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.35 }}
        className="mt-14 p-4 rounded-2xl bg-[#1b1f27] border border-[#d5c3aa]/15 text-center text-xs text-slate-300 flex flex-col sm:flex-row items-center justify-center gap-2"
      >
        <span className="text-[#d5c3aa] font-semibold tracking-wider uppercase text-[11px]">Archive Note:</span>
        <span>
          These featured cards represent design and functional prototypes. Production links and public
          repositories will be populated as full deployment cycles complete.
        </span>
      </motion.div>

      {/* Modal View */}
      {selectedProject && (
        <ConceptModal
          project={selectedProject}
          mode={modalMode}
          onClose={closeModal}
        />
      )}

    </motion.section>
  );
}
