import { useState } from 'react';
import { X, ExternalLink, Code2, Sparkles, Send, CheckCircle2 } from 'lucide-react';
import type { ProjectItem } from '../types';

interface ConceptModalProps {
  project: ProjectItem | null;
  mode: 'demo' | 'code' | null;
  onClose: () => void;
}

export default function ConceptModal({ project, mode, onClose }: ConceptModalProps) {
  if (!project) return null;

  const [interactiveInput, setInteractiveInput] = useState('');
  const [demoFeedback, setDemoFeedback] = useState<string | null>(null);
  const [selectedFormat, setSelectedFormat] = useState('1080p (FHD)');

  const handleInteractiveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!interactiveInput.trim()) return;
    setDemoFeedback(`Concept simulated: "${interactiveInput}". Real-time processing pipeline will execute here upon API backend deployment.`);
    setInteractiveInput('');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto"
    >
      <div
        className="relative w-full max-w-3xl my-8 rounded-[28px] marble-card border border-[#d5c3aa]/25 bg-[#1a1e27] shadow-2xl overflow-hidden text-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 sm:px-8 py-5 border-b border-white/10 bg-[#14171d]/80">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-[#d5c3aa]" />
            <h3 id="modal-title" className="text-lg font-bold text-[#f5f3ef] tracking-wide">
              {project.title}
            </h3>
            <span className="text-[10px] font-mono uppercase bg-[#d5c3aa]/10 text-[#d5c3aa] border border-[#d5c3aa]/30 px-2.5 py-0.5 rounded-full">
              Marble Prototype
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#d5c3aa]"
            aria-label="Close concept preview"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {/* Hero Visual Preview */}
          <div className="relative rounded-2xl overflow-hidden border border-white/10 aspect-video sm:aspect-[16/9] bg-slate-950">
            <img
              src={project.image}
              alt={project.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1a1e27] via-transparent to-transparent opacity-80" />
            <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-slate-300">
              <span className="bg-black/70 backdrop-blur-md px-3 py-1 rounded-full border border-white/10 font-mono text-[11px] text-[#d5c3aa]">
                Concept UI Showcase
              </span>
              <span className="bg-[#14171d]/80 border border-[#d5c3aa]/40 text-[#f5f3ef] px-3 py-1 rounded-full text-[11px]">
                The Prototype Series
              </span>
            </div>
          </div>

          {/* Description & Status Notice */}
          <div className="space-y-3">
            <h4 className="text-base font-bold text-[#f5f3ef] tracking-wide">Project Overview</h4>
            <p className="text-sm text-slate-300 leading-relaxed">
              {project.description}
            </p>
            <p className="text-xs text-slate-300 leading-relaxed italic bg-black/25 p-3.5 rounded-xl border border-white/[0.06]">
              <strong className="text-[#d5c3aa] not-italic">Developer Note:</strong> This is a conceptual
              prototype designed by Ankit Baghel to demonstrate interface architecture, user interaction
              flows, and aesthetic direction. Real backend infrastructure and GitHub repositories will be
              linked as production implementation concludes.
            </p>
          </div>

          {/* Technology Tags */}
          <div>
            <h4 className="text-xs font-semibold text-[#d5c3aa] uppercase tracking-marble mb-2">
              Technology Stack Focus
            </h4>
            <div className="flex flex-wrap gap-2 text-xs">
              {project.tags.map((tag) => (
                <span
                  key={tag}
                  className="bg-[#14171d] border border-[#d5c3aa]/20 text-[#e4d7c5] px-3 py-1 rounded-full font-mono text-[11px]"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Key Concept Features */}
          <div>
            <h4 className="text-xs font-semibold text-[#d5c3aa] uppercase tracking-marble mb-2">
              Key Architectural Goals
            </h4>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-slate-300">
              {project.features.map((feat, i) => (
                <li key={i} className="flex items-start gap-2 bg-[#14171d]/70 p-3 rounded-xl border border-white/[0.05]">
                  <CheckCircle2 className="w-4 h-4 text-[#d5c3aa] shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Interactive Prototype Simulation Area */}
          <div className="p-5 rounded-2xl bg-[#14171d]/90 border border-[#d5c3aa]/25 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#d5c3aa] tracking-wide">
              <Sparkles className="w-4 h-4 text-[#d5c3aa]" />
              <span>Interactive Concept Simulation</span>
            </div>

            {project.id === 'ai-assistant' && (
              <form onSubmit={handleInteractiveSubmit} className="space-y-2">
                <p className="text-xs text-slate-400">
                  Try typing a sample prompt into the conversational concept bar:
                </p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={interactiveInput}
                    onChange={(e) => setInteractiveInput(e.target.value)}
                    placeholder="e.g., Analyze the quantum array optimization..."
                    className="flex-1 bg-[#1a1e27] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#d5c3aa]"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 btn-marble-sand text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5 text-[#171a21]" />
                    <span>Test</span>
                  </button>
                </div>
              </form>
            )}

            {project.id === 'video-downloader' && (
              <div className="space-y-2 text-xs">
                <p className="text-slate-400">Select target resolution preset for previewing utility state:</p>
                <div className="flex flex-wrap gap-2">
                  {['4K (2160p)', '1440p (QHD)', '1080p (FHD)', '720p (HD)'].map((fmt) => (
                    <button
                      key={fmt}
                      onClick={() => {
                        setSelectedFormat(fmt);
                        setDemoFeedback(`Selected target preset: ${fmt}. Stream muxing parameter configured.`);
                      }}
                      className={`px-3 py-1.5 rounded-full border text-xs transition-colors ${
                        selectedFormat === fmt
                          ? 'bg-[#d5c3aa] border-[#d5c3aa] text-[#171a21] font-semibold'
                          : 'bg-[#1a1e27] border-white/10 text-slate-400 hover:text-white'
                      }`}
                    >
                      {fmt}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {project.id === 'food-scanner' && (
              <div className="space-y-2 text-xs">
                <p className="text-slate-400">Simulate nutritional ingredient query:</p>
                <button
                  type="button"
                  onClick={() =>
                    setDemoFeedback('Label recognized: Organic Quinoa & Kale Blend (Score: 94/100). Macros: 32% Protein, 56% Carbs, 12% Healthy Fats.')
                  }
                  className="px-4 py-2 btn-marble-sand text-xs font-semibold"
                >
                  Simulate QR / Barcode Scan
                </button>
              </div>
            )}

            {demoFeedback && (
              <div className="text-xs text-[#d5c3aa] bg-[#d5c3aa]/10 p-3 rounded-xl border border-[#d5c3aa]/30">
                {demoFeedback}
              </div>
            )}
          </div>

        </div>

        {/* Modal Footer */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-6 sm:px-8 py-4 border-t border-white/10 bg-[#14171d]/90">
          <div className="text-xs text-slate-400 flex items-center gap-1.5">
            {mode === 'code' ? (
              <>
                <Code2 className="w-4 h-4 text-[#d5c3aa]" />
                <span>Source repository placeholder (pending release)</span>
              </>
            ) : (
              <>
                <ExternalLink className="w-4 h-4 text-[#d5c3aa]" />
                <span>Concept interface preview active</span>
              </>
            )}
          </div>

          <div className="flex items-center gap-3">
            <a
              href={`mailto:ab40510245@gmail.com?subject=${encodeURIComponent(
                `Regarding ${project.title} concept`
              )}`}
              className="px-5 py-2 text-xs font-semibold btn-marble-sand"
            >
              Discuss with Ankit
            </a>
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium btn-marble-outline"
            >
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
