import { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import type { NavItem } from '../types';

const navItems: NavItem[] = [
  { name: 'Home', href: '#home' },
  { name: 'About', href: '#about' },
  { name: 'Skills', href: '#skills' },
  { name: 'Projects', href: '#projects' },
  { name: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);

      // Calculate scroll progress percentage (0 to 100)
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (totalScroll > 0) {
        const progress = (window.scrollY / totalScroll) * 100;
        setScrollProgress(Math.min(100, Math.max(0, progress)));
      } else {
        setScrollProgress(0);
      }

      const sections = ['home', 'about', 'skills', 'projects', 'contact'];
      const scrollPosition = window.scrollY + 200;

      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (href: string) => {
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Subtle, slim antique champagne progress indicator bar pinned at the top */}
      <div
        className="fixed top-0 left-0 right-0 h-[2.5px] z-[60] pointer-events-none bg-[#14171d]/30"
        aria-hidden="true"
      >
        <div
          className="h-full bg-gradient-to-r from-[#d5c3aa]/40 via-[#e4d7c5]/85 to-[#d5c3aa] transition-[width] duration-100 ease-out shadow-[0_0_8px_rgba(213,195,170,0.45)]"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-[#14171d]/90 backdrop-blur-md border-b border-[#d5c3aa]/10 py-3.5 shadow-lg shadow-black/40'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8">
          
          {/* Brand Zone: Marble Identity Wordmark */}
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              scrollTo('#home');
            }}
            className="flex items-center gap-3 group whitespace-nowrap shrink-0 text-slate-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#d5c3aa] rounded-lg p-1"
            aria-label="Ankit Baghel Portfolio Home"
          >
            <div className="w-8 h-8 rounded-full border border-[#d5c3aa]/40 bg-[#1c2028] flex items-center justify-center text-[#d5c3aa] text-xs font-semibold tracking-wider group-hover:border-[#d5c3aa] transition-colors shadow-sm">
              AB
            </div>
            <div className="flex flex-col">
              <span className="font-semibold text-sm tracking-marble uppercase text-[#f5f3ef] group-hover:text-[#d5c3aa] transition-colors">
                Ankit Baghel
              </span>
              <span className="text-[10px] text-[#9ca3af] tracking-widest lowercase">
                creative digital explorer
              </span>
            </div>
          </a>

          {/* Navigation Zone (Desktop) */}
          <nav
            className="hidden md:flex items-center gap-7 text-xs font-medium tracking-wider lowercase text-slate-300"
            aria-label="Main Navigation"
          >
            {navItems.map((item) => {
              const isActive = activeSection === item.href.substring(1);
              return (
                <button
                  key={item.name}
                  onClick={() => scrollTo(item.href)}
                  className={`relative py-1 transition-all duration-200 hover:text-white cursor-pointer ${
                    isActive
                      ? 'text-[#f5f3ef] font-semibold'
                      : 'text-slate-400 hover:text-[#d5c3aa]'
                  }`}
                >
                  <span>{item.name}</span>
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-[#d5c3aa] rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action Zone: Champagne Sand Button ("view identity" style) */}
          <div className="hidden md:flex items-center gap-3 shrink-0">
            <a
              href="mailto:ab40510245@gmail.com"
              className="inline-flex items-center gap-2 px-5 py-2 text-xs font-medium tracking-wide btn-marble-sand shadow-sm cursor-pointer"
            >
              <span>view identity</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#171a21]" />
            </a>
          </div>

          {/* Mobile Hamburger Button */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/[0.08] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#d5c3aa]"
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileMenuOpen}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu Overlay */}
        {mobileMenuOpen && (
          <div className="md:hidden fixed inset-x-0 top-[65px] bg-[#14171d]/95 backdrop-blur-xl border-b border-[#d5c3aa]/15 px-6 py-6 shadow-2xl transition-all">
            <nav className="flex flex-col gap-3">
              {navItems.map((item) => {
                const isActive = activeSection === item.href.substring(1);
                return (
                  <button
                    key={item.name}
                    onClick={() => scrollTo(item.href)}
                    className={`text-left px-4 py-3 rounded-xl text-sm tracking-wider font-medium transition-colors ${
                      isActive
                        ? 'bg-[#1f232b] text-[#d5c3aa] border border-[#d5c3aa]/20 font-semibold'
                        : 'text-slate-300 hover:bg-white/[0.05] hover:text-white'
                    }`}
                  >
                    {item.name}
                  </button>
                );
              })}
              <div className="pt-3 border-t border-white/[0.08] mt-2">
                <a
                  href="mailto:ab40510245@gmail.com"
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm btn-marble-sand"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span>view identity</span>
                  <ArrowUpRight className="w-4 h-4 text-[#171a21]" />
                </a>
              </div>
            </nav>
          </div>
        )}
      </header>
    </>
  );
}
