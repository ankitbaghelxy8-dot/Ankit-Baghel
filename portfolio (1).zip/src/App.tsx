/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import ThreeCanvas from './components/ThreeCanvas';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import SkillsSection from './components/SkillsSection';
import ProjectsSection from './components/ProjectsSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="relative min-h-screen bg-[#14171d] text-slate-100 font-sans selection:bg-[#d5c3aa]/30 selection:text-[#f5f3ef]">
      {/* Interactive Classical Marble 3D WebGL Canvas Layer */}
      <ThreeCanvas />

      {/* Atmospheric lighting accents in antique champagne and alabaster mist */}
      <div
        aria-hidden="true"
        className="fixed inset-0 pointer-events-none z-0 overflow-hidden"
      >
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-[#d5c3aa]/6 rounded-full blur-[140px]" />
        <div className="absolute top-1/2 right-10 w-[600px] h-[600px] bg-[#9ca9bb]/5 rounded-full blur-[160px]" />
        <div className="absolute bottom-10 left-10 w-[500px] h-[500px] bg-[#c4b197]/5 rounded-full blur-[150px]" />
      </div>

      {/* Foreground Content Structure */}
      <div className="relative z-10 flex flex-col min-h-screen">
        <Navbar />
        
        <main className="flex-1">
          <HeroSection />
          <AboutSection />
          <SkillsSection />
          <ProjectsSection />
          <ContactSection />
        </main>

        <Footer />
      </div>
    </div>
  );
}
